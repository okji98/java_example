package com.example.spro00;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spro00ApplicationTests {

	@Test
	void contextLoads() {
	}

}
