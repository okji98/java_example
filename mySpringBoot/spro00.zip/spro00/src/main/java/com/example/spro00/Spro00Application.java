package com.example.spro00;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spro00Application {

	public static void main(String[] args) {
		SpringApplication.run(Spro00Application.class, args);
	}

}
