package com.example.spro02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spro02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
