package com.example.spro02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spro02Application {

	public static void main(String[] args) {
		SpringApplication.run(Spro02Application.class, args);
	}

}
