package com.example.spro02.repository;

import com.example.spro02.domain.RefreshToken;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {
    Optional<RefreshToken> findUserById(Long userId);
    Optional<RefreshToken> findByRefreshToken(String refreshToken);
}
